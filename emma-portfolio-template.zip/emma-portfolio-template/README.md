# Emma Portfolio Template

A React/Vite portfolio template inspired by an interactive floating visual archive.

## How to use

1. Upload this folder to GitHub.
2. Make sure the following files are placed in the `public` folder:
   - `emma-foto.png`
   - `ficq-partners.jpg`
   - `groenteboer.jpg`
   - `japan-2024.jpg`
   - `juul1.jpg`
   - `postkaartje1.png`
   - `postkaartje2.png`
   - `postkaartje3.png`
   - `song1.jpg`
   - `song1.mp3`
   - `song2.jpg`
   - `song2.mp3`
   - `emma-cv.pdf` if you want to link to your CV later
3. Run:

```bash
npm install
npm run dev
```

## Deploy with GitHub Pages / Vercel / Netlify

This is a normal Vite React app. Vercel or Netlify will usually detect it automatically.
